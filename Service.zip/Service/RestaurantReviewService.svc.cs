﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace Lab6Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class RestaurantReviewService : IRestaurantReviewService
    {
        private restaurants GetRestaurantsFromXml()
        {
            restaurants mylist = null;
            string xmlPath = HttpContext.Current.Server.MapPath("~/App_Data/restaurant_reviews.xml");
            using (FileStream xml = new FileStream(xmlPath, FileMode.Open))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(restaurants));
                mylist = (restaurants)serializer.Deserialize(xml);
                xml.Close();
                xml.Dispose();
            }
            return mylist;
        }

        public List<string> GetRestaurantNames()
        {
            List<string> restnames = new List<string>();
            restaurants allrestaurants = GetRestaurantsFromXml();
            if (allrestaurants != null)
            {
                foreach (restaurantsRestaurant rest in allrestaurants.restaurant)
                {
                    restnames.Add(rest.name);
                }
            }
            return restnames;
        }

        public List<RestaurantInfo> GetAllRestaurants()
        {
            List<RestaurantInfo> restnames = new List<RestaurantInfo>();
            restaurants allrestaurants = GetRestaurantsFromXml();

            if (allrestaurants != null)
            {
                int i = 1;
                foreach (restaurantsRestaurant rest in allrestaurants.restaurant)
                {
                    RestaurantInfo reinfo = new RestaurantInfo();
                    reinfo.Id = i;
                    reinfo.Name = rest.name;
                    reinfo.Summary = rest.summary;
                    reinfo.Cost = rest.priceReview.Value;
                    reinfo.FoodType = rest.food;
                    reinfo.Rating = rest.rating.Value;

                    Address add = new Address();
                    add.PostalCode = rest.address.postalCode;
                    add.City = rest.address.city.ToString();
                    add.Province = rest.address.province;
                    add.Street = rest.address.streetName;

                    reinfo.Location = add;
                    restnames.Add(reinfo);
                    i++;
                }
            }
            return restnames;
        }

        public RestaurantInfo GetRestaurantById(int id)
        {
            RestaurantInfo ret = null;
            List<RestaurantInfo> allrestinfo = GetAllRestaurants();
            foreach (RestaurantInfo restinfo in allrestinfo)
            {
                if (restinfo.Id == id)
                {
                    ret = restinfo;
                }
            }
            return ret;
        }

        public bool SaveRestaurant(RestaurantInfo restInfo)
        {
            bool saveresult = false;
            restaurants allrestaurants = GetRestaurantsFromXml();
            int i = 1;
            foreach (restaurantsRestaurant rest in allrestaurants.restaurant)
            {
                if (restInfo.Id == i)
                {
                    rest.name = restInfo.Name;
                    rest.summary = restInfo.Summary;
                    rest.priceReview.Value = (byte)restInfo.Cost;
                    rest.food = restInfo.FoodType;
                    rest.address.streetName = restInfo.Location.Street;
                    rest.rating.Value = (byte)restInfo.Rating;
                    rest.address.postalCode = restInfo.Location.PostalCode;
                    rest.address.city = restInfo.Location.City;
                    rest.address.province = restInfo.Location.Province;
                }
                i++;
            }
            XmlSerializer seri = new XmlSerializer(typeof(restaurants));
            string xmlPath = HttpContext.Current.Server.MapPath("~/App_Data/restaurant_reviews.xml");
            XmlTextWriter xmlw = new XmlTextWriter(xmlPath, Encoding.UTF8);

            seri.Serialize(xmlw, allrestaurants);
            xmlw.Close();
            saveresult = true;
            return saveresult;
        }
    }
}
